<!DOCTYPE html>
<html>
<head>
	<title>whatsapp</title>
     <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="css/chat.css">
</head>
<body>


	<!--navbar-->
	<nav class="navbar navbar-expand-lg navbar-dark text-weight-bold text-white bg-dark" >
	  <a class="navbar-brand " style="width: 30%" href="#"><h3>Whatsapp</h3></a>
       <div class="name ml-auto text-center " style=" width: 60%; align-items: right;">
	  <div class="name" style="display: flex;flex-direction: right;float: right;">

        
        


        <div class="text-center align-items-center " id="profile" style="display: flex;padding-right:2vh;">
        
        <?php 
            include 'connection.php';

        

        $query5="SELECT * FROM `user-data` WHERE uname='".$_SESSION['chatfrom']."'";
        $run5=mysqli_query($con,$query5);

        if ($data=mysqli_fetch_array($run5)) {

            $image="images/".$data['photoname'];

      ?>
            
       <img src="<?php echo $image; ?>" alt="icon" style="width:4vh;border-radius: 20vh;">

    <?php
}

        echo "<h6>Hello ".$_SESSION['chatfrom']."</h6>";


        $chatroom=$_SESSION['chatfrom']."-".$_SESSION['chatto'];

        $chatroom1=$_SESSION['chatto']."-".$_SESSION['chatfrom'];

        $query1="SELECT * FROM `".$chatroom."` WHERE 1";
        $run1=mysqli_query($con,$query1);



         $query2="SELECT * FROM `".$chatroom1."` WHERE 1";
         $run2=mysqli_query($con,$query2);


        if ($run1==TRUE) {
             
            
        }

        elseif ($run2==TRUE) {

         
        }
        else{

                 $query="CREATE TABLE `whatsapp`.`".$chatroom."` ( `msg` TEXT NOT NULL , `time` TEXT NOT NULL , `from` TEXT NOT NULL , `to` TEXT NOT NULL , `type` TEXT NOT NULL , `filename` TEXT NOT NULL , `filelocation` TEXT NOT NULL ) ENGINE = InnoDB;";

                $run=mysqli_query($con,$query);

                if ($run==TRUE) {
                    
                    
                }
                else{
                    echo "ERROR";
                }


        }


        

        ?>
    </div>
    <form action="search-friends.php" class="align-items-center text-center" style="align-content: center;padding-top: 2vh; padding-right: 2vh;">
                
            
            <button class="btn btn-danger text-center" style="font-size:2vh;">Search-friends</button>

        </form>

    <form id="logout" action="php/logout.php" class="align-items-center text-center" style="align-content: center;padding-top: 2vh;">
                
            
            <button class="btn btn-danger text-center">LOG-OUT</button>

        </form>

        


      </div>

	</nav>

<!--main-->

<div>
    <div class=" d-flex justify-content-center text-center rounded " id="top" style="background-color:#ff6f08;">

        <?php

        $query5="SELECT * FROM `user-data` WHERE uname='".$_SESSION['chatto']."'";
        $run5=mysqli_query($con,$query5);

        if ($data=mysqli_fetch_array($run5)) {

            $image="images/".$data['photoname'];

      ?>
            
        <img src="<?php echo $image; ?>" alt="icon" style="width:9vh;height: 9vh;padding-right: 2vh;border-radius: 20px;">
        <h4 style="padding-top: 2vh;"><?php echo $_SESSION['chatto'];  ?></h4>

    <?php
}
    ?>
    </div>
   

    <div class="container-fluid" style="height:57vh;overflow-y: scroll;background-color:  #e6ffff;" id="chats"> 
        

       

      


    </div>


    <script type="text/javascript">
        

        var from=<?php echo "'".$_SESSION['chatfrom']."'";?>;
        var to=<?php echo "'".$_SESSION['chatto']."'";?>;


        window.setInterval(reloadmsg,1000);


        function reloadmsg(){

            $.ajax({
                url:'php/reload.php',
                type:'post',
                data:{
                    from:from,
                    to:to
                },
                success:function(data){
                    $("#chats").empty();
                    $("#chats").append(data);

                }
            });

        }





    </script>

</div>



<!--bottom-->
<div id="bottom" class="bg-dark fixed-bottom" style="font-size: 1vh;">
    
    <div id="msg and doc" style="display: flex;padding-top: 20px;">

        <div id="msg" style="width: 50%;">

            <form id="input-data" action="#" method="post" class="col-sm-6  span-6 justify-content-center text-center" style="" >
                          <input type="text" class="form-control" placeholder="Message" name="message" id="msg" >
                          
                            <button id="send" class="btn btn-success" name="send">SEND</button>

                            <div class="hidden" id="storedata">

                                <input type="hidden" name="dat" value="time">

                            </div>

                        

                </form>
                




                <script type="text/javascript">
                    
                    $("#send").click(function(){

                            var currentdate = new Date();
                            var datetime = currentdate.getDate() + "/" + (currentdate.getMonth()+1) 
                            + "/" + currentdate.getFullYear()+ " @ " 
                            + currentdate.getHours() + ":" 
                            + currentdate.getMinutes() + ":" + currentdate.getSeconds();


                            console.log(datetime);

                        var msg=$("#msg").val();
                        var time=datetime;
                        var from=<?php echo "'".$_SESSION['chatfrom']."'";?>;
                        var to=<?php echo "'".$_SESSION['chatto']."'";?>;

                        console.log(msg,time,from,to);

                        $.ajax({
                            url:'php/addmsg.php',
                            type:'POST',
                            data:
                                {
                                msg:msg,
                                time:time,
                                from:from,
                                to:to
                            },
                            success:function(data){
                                console.log(data);
                            }
                        });




                    });




                </script>

            


        </div>

        <div id="doc" style="width:50%;margin-left: 0;">
            
                    <form action="php/uploaddoc.php" method="post" enctype="multipart/form-data" class="col-sm-3 span-6 justify-content-center text-center">
                    

                    <input type="file" name="file" style="font-size: 1.5vh; height: 5vh;">
                    <br>
                    <input class="btn btn-success" type="submit" name="submit">


                </form>

        </div>
        


    </div>


    <div class="text-white text-center">
        
    <h6>This website is designed by TUSHAR KARLE.</h6>

    </div>
   




</div>

          
            



</body>
</html>

  <script type="text/javascript">
           
           $("#chats").animate({ scrollTop: $(document).height() }, 1000);
         </script>













 
        
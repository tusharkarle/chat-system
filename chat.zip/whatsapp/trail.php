<?php



$time_now=mktime(date('h')+4,date('i')+30,date('s'));
$date = date('d/m/Y  @ h:i:s', $time_now);
echo $date;



?>
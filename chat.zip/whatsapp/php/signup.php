<?php 

$fullname=$_POST['fullname'];
$mail=$_POST['mail'];
$uname=$_POST['uname'];
$password=$_POST['pswd'];

$file=$_FILES['photo'];


$filename=$file['name'];

$tmp_name=$file['tmp_name'];

$filetype=$file['type'];


$extension = pathinfo($filename, PATHINFO_EXTENSION);



$folder="../images/".$filename;

if($extension=='jpg' || $extension=='jpeg' || $extension=='png' || $extension=='gif'){




			move_uploaded_file($tmp_name, $folder);





			$con=mysqli_connect('localhost','root','','whatsapp');


			$query="INSERT INTO `user-data`(`fullname`, `mail`, `uname`, `password`,`photoname`) VALUES ('$fullname','$mail','$uname','$password','$filename')";


			$run=mysqli_query($con,$query);


			if ($run==TRUE) {

				echo "success";
			}
			else {
				
				echo "unsuccess";

				}




}

else{

	echo "<h4>please upload iamge onl</h4>";
}





















?>
<?php



$from=$_POST['from'];
$to=$_POST['to'];



include 'connection.php';


		$chatroom=$from."-".$to;

      	$chatroom1=$to."-".$from;

          $query1="SELECT * FROM `".$chatroom."` WHERE 1";
        $run1=mysqli_query($con,$query1);



         $query2="SELECT * FROM `".$chatroom1."` WHERE 1";
         $run2=mysqli_query($con,$query2);


        if ($run1==TRUE) {
             

				
				
				while($data=mysqli_fetch_array($run1))
				{
						
					if ($data['type']=="message") {
						
						if ($data['from']==$from) {
							echo "<br>";

						echo "<div class='row'>";
						echo "<div class=' col-sm-3 col-xl-4  ml-auto rounded text-right' style='background-color:#9fff80;'>";
						echo "<h4 class='text-success'> You:</h4>";
						echo"<h4>".$data['msg']."</h4>";
						echo"<h7>".$data['time']."</h7>";
						echo "</div>";
						echo "</div>";
						echo "<br>";

						}

						else{

						echo "<br>";
						echo "<div class='row'>";
						echo "<div class='col-sm-3 col-xl-4  mr-auto rounded text-left' style='background-color: #ede664;'>";
						echo "<h4 class='text-primary'>".$data['from']."</h4>";
						echo"<h4>".$data['msg']."</h4>";
						echo"<h7>".$data['time']."</h7>";
						echo "</div>";
						echo "</div>";
						echo "<br>";
						}

					}

					elseif ($data['type']=="image" || $data['type']=="pdf") {

						if ($data['from']==$from) {

						echo "<div class='row'>";
						echo "<div class=' col-sm-3 col-xl-4  ml-auto rounded text-right' style='background-color:#9fff80;'>";
						echo "<h4 class='text-success'> You:</h4>";
						echo("<img src='".$data['filelocation']."' height='30vh' width='30vh' style='height:70%; width:80%;border-style: solid;'>");
						echo("<a href='".$data['filelocation']."' download>DOWNLOAD</a>");
						echo"<h7>".$data['time']."</h7>";
						echo "</div>";
						echo "</div>";
						echo "<br>";

						}

						else{

						echo "<div class='row'>";
						echo "<div class='col-sm-3 col-xl-4 mr-auto rounded text-left' style='background-color: #ede664;'>";
						echo "<h4 class='text-primary'>".$data['from'].":</h4>";
						echo("<img src='".$data['filelocation']."' height='30vh' width='30vh' style='height:70%; width:80%;border-style: solid;'>");
						echo("<a href='".$data['filelocation']."' download>DOWNLOAD</a>");
						echo"<h7>".$data['time']."</h7>";
						echo "</div>";
						echo "</div>";
						echo "<br>";
						}
						
					}
					
				}
				
				
			

        }

        elseif ($run2==TRUE) {

        		
				
				while($data=mysqli_fetch_array($run2))
				{
						
					if ($data['type']=="message") {
						
						if ($data['from']==$from) {
							echo "<br>";

						echo "<div class='row'>";
						echo "<div class=' col-sm-3 col-xl-4  ml-auto rounded text-right' style='background-color:#9fff80;'>";
						echo "<h4 class='text-success'> You:</h4>";
						echo"<h4>".$data['msg']."</h4>";
						echo"<h7>".$data['time']."</h7>";
						echo "</div>";
						echo "</div>";
						echo "<br>";

						}

						else{

						echo "<br>";
						echo "<div class='row'>";
						echo "<div class='col-sm-3 col-xl-4  mr-auto rounded text-left' style='background-color: #ede664;'>";
						echo "<h4 class='text-primary'>".$data['from']."</h4>";
						echo"<h4>".$data['msg']."</h4>";
						echo"<h7>".$data['time']."</h7>";
						echo "</div>";
						echo "</div>";
						echo "<br>";
						}

					}

					elseif ($data['type']=="image" || $data['type']=="pdf") {

						if ($data['from']==$from) {

						echo "<div class='row'>";
						echo "<div class=' col-sm-3 col-xl-4  ml-auto rounded text-right' style='background-color:#9fff80;'>";
						echo "<h4 class='text-success'> You:</h4>";
						echo("<img src='".$data['filelocation']."'  height='30vh' width='30vh' style='height:70%; width:80%;border-style: solid;'>");
						echo("<a href='".$data['filelocation']."' download >DOWNLOAD</a>");
						echo"<h7>".$data['time']."</h7>";
						echo "</div>";
						echo "</div>";
						echo "<br>";

						}

						else{

						echo "<div class='row'>";
						echo "<div class='col-sm-3 col-xl-4 mr-auto rounded text-left' style='background-color: #ede664;'>";
						echo "<h4 class='text-primary'>".$data['from'].":</h4>";
						echo("<img src='".$data['filelocation']."' height='30vh' width='30vh' style='height:70%; width:80%;border-style: solid;'>");
						echo("<a href='".$data['filelocation']."' download>DOWNLOAD</a>");
						echo"<h7>".$data['time']."</h7>";
						echo "</div>";
						echo "</div>";
						echo "<br>";
						}
						
					}
					
				}
    }
  else{

        	echo "<h1>cannot3</h1>";
        }
 

?>
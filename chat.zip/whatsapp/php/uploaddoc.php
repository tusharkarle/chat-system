<?php

$file=$_FILES['file'];
$filename=$file['name'];

$tmp=$file['tmp_name'];

$extension = pathinfo($filename, PATHINFO_EXTENSION);

$loc='../documents/'.$file['name'];


include 'connection.php';
 $chatroom=$_SESSION['chatfrom']."-".$_SESSION['chatto'];

 $chatroom1=$_SESSION['chatto']."-".$_SESSION['chatfrom'];


$from=$_SESSION['chatfrom'];
$to=$_SESSION['chatto'];

$time_now=mktime(date('h')+4,date('i')+30,date('s'));
$time = date('d/m/Y  @ h:i:s', $time_now);






if($extension=='jpg' || $extension=='jpeg' || $extension=='png' || $extension=='gif'){

	$createfolder=is_dir("../documents/images/".$chatroom."/");
	$createfolder1=is_dir("../documents/images/".$chatroom1."/");


	
	if ($createfolder==TRUE) {

		$location="documents/images/".$chatroom."/".$filename."";
		$location1="../documents/images/".$chatroom."/".$filename."";
		move_uploaded_file($tmp,$location1);


				$query1="SELECT * FROM `".$chatroom."` WHERE 1";
		        $run1=mysqli_query($con,$query1);



		         $query2="SELECT * FROM `".$chatroom1."` WHERE 1";
		         $run2=mysqli_query($con,$query2);


		        if ($run1==TRUE) {
		             


						$query3="INSERT INTO `".$chatroom."`(`time`, `from`, `to`,`type`, `filename`, `filelocation`) VALUES ('$time','$from','$to','image','$filename','$location')";

						$run=mysqli_query($con,$query3);


						if ($run==TRUE) {
								
							echo "<h1>done</h1>";
							header('location:../chat.php');
							
						}

						else{
							echo "<h1>cannot1</h1>";
							header('location:../chat.php');
						}
		        }

		        elseif ($run2==TRUE) {

		        	
						$query4="INSERT INTO `".$chatroom1."`(`time`, `from`, `to`,`type`, `filename`, `filelocation`) VALUES ('$time','$from','$to','image','$filename','$location')";

						$run=mysqli_query($con,$query4);


						if ($run==TRUE) {
								
							echo "<h1>done</h1>";
							header('location:../chat.php');
						}

						else{
							echo "<h1>cannot2</h1>";
							header('location:../chat.php');
						}

		                 
		        }
		        else{

		        	echo "<h1>cannot3</h1>";
		        }
				
				
		
	}
	elseif ($createfolder1==TRUE) {
		
		$location="documents/images/".$chatroom1."/".$filename."";
		$location1="../documents/images/".$chatroom1."/".$filename."";
		move_uploaded_file($tmp,$location1);


				$query1="SELECT * FROM `".$chatroom."` WHERE 1";
		        $run1=mysqli_query($con,$query1);



		         $query2="SELECT * FROM `".$chatroom1."` WHERE 1";
		         $run2=mysqli_query($con,$query2);


		        if ($run1==TRUE) {
		             


						$query3="INSERT INTO `".$chatroom."`(`time`, `from`, `to`,`type`, `filename`, `filelocation`) VALUES ('$time','$from','$to','image','$filename','$location')";

						$run=mysqli_query($con,$query3);


						if ($run==TRUE) {
								
							echo "<h1>done</h1>";
							header('location:../chat.php');
						}

						else{
							echo "<h1>cannot1</h1>";
							header('location:../chat.php');
						}
		        }

		        elseif ($run2==TRUE) {

		        	
						$query4="INSERT INTO `".$chatroom1."`(`time`, `from`, `to`,`type`, `filename`, `filelocation`) VALUES ('$time','$from','$to','image','$filename','$location')";

						$run=mysqli_query($con,$query4);


						if ($run==TRUE) {
								
							echo "<h1>done</h1>";
							header('location:../chat.php');
						}

						else{
							echo "<h1>cannot2</h1>";
							header('location:../chat.php');
						}

		                 
		        }
		        else{

		        	echo "<h1>cannot3</h1>";
		        }
		
	}
	else{
		mkdir("../documents/images/".$chatroom."");

		$location="documents/images/".$chatroom."/".$filename."";
		$location1="../documents/images/".$chatroom."/".$filename."";
		move_uploaded_file($tmp,$location1);


				$query1="SELECT * FROM `".$chatroom."` WHERE 1";
		        $run1=mysqli_query($con,$query1);



		         $query2="SELECT * FROM `".$chatroom1."` WHERE 1";
		         $run2=mysqli_query($con,$query2);


		        if ($run1==TRUE) {
		             


						$query3="INSERT INTO `".$chatroom."`(`time`, `from`, `to`,`type`, `filename`, `filelocation`) VALUES ('$time','$from','$to','image','$filename','$location')";

						$run=mysqli_query($con,$query3);


						if ($run==TRUE) {
								
							echo "<h1>done</h1>";
							header('location:../chat.php');
						}

						else{
							echo "<h1>cannot1</h1>";
							header('location:../chat.php');
						}
		        }

		        elseif ($run2==TRUE) {

		        	
						$query4="INSERT INTO `".$chatroom1."`(`time`, `from`, `to`,`type`, `filename`, `filelocation`) VALUES ('$time','$from','$to','image','$filename','$location')";

						$run=mysqli_query($con,$query4);


						if ($run==TRUE) {
								
							echo "<h1>done</h1>";
							header('location:../chat.php');
						}

						else{
							echo "<h1>cannot2</h1>";
							header('location:../chat.php');
						}

		                 
		        }
		        else{

		        	echo "<h1>cannot3</h1>";
		        }


	}

}

elseif ($extension=='pdf') {
	
	$createfolder=is_dir("../documents/pdf/".$chatroom."/");
	$createfolder1=is_dir("../documents/pdf/".$chatroom1."/");


	
	if ($createfolder==TRUE) {

		$location="documents/pdf/".$chatroom."/".$filename."";
		$location1="../documents/pdf/".$chatroom."/".$filename."";
		move_uploaded_file($tmp,$location1);

				$query1="SELECT * FROM `".$chatroom."` WHERE 1";
		        $run1=mysqli_query($con,$query1);



		         $query2="SELECT * FROM `".$chatroom1."` WHERE 1";
		         $run2=mysqli_query($con,$query2);


		        if ($run1==TRUE) {
		             


						$query3="INSERT INTO `".$chatroom."`(`time`, `from`, `to`,`type`, `filename`, `filelocation`) VALUES ('$time','$from','$to','image','$filename','$location')";

						$run=mysqli_query($con,$query3);


						if ($run==TRUE) {
								
							echo "<h1>done</h1>";
							header('location:../chat.php');
						}

						else{
							echo "<h1>cannot1</h1>";
							header('location:../chat.php');
						}
		        }

		        elseif ($run2==TRUE) {

		        	
						$query4="INSERT INTO `".$chatroom1."`(`time`, `from`, `to`,`type`, `filename`, `filelocation`) VALUES ('$time','$from','$to','image','$filename','$location')";

						$run=mysqli_query($con,$query4);


						if ($run==TRUE) {
								
							echo "<h1>done</h1>";
							header('location:../chat.php');
						}

						else{
							echo "<h1>cannot2</h1>";
							header('location:../chat.php');
						}

		                 
		        }
		        else{

		        	echo "<h1>cannot3</h1>";
		        	header('location:../chat.php');
		        }
				
				
		
	}
	elseif ($createfolder1==TRUE) {
		
		$location="documents/pdf/".$chatroom1."/".$filename."";
		$location1="../documents/pdf/".$chatroom1."/".$filename."";
		move_uploaded_file($tmp,$location1);

				$query1="SELECT * FROM `".$chatroom."` WHERE 1";
		        $run1=mysqli_query($con,$query1);



		         $query2="SELECT * FROM `".$chatroom1."` WHERE 1";
		         $run2=mysqli_query($con,$query2);


		        if ($run1==TRUE) {
		             


						$query3="INSERT INTO `".$chatroom."`(`time`, `from`, `to`,`type`, `filename`, `filelocation`) VALUES ('$time','$from','$to','image','$filename','$location')";

						$run=mysqli_query($con,$query3);


						if ($run==TRUE) {
								
							echo "<h1>done</h1>";
							header('location:../chat.php');
						}

						else{
							echo "<h1>cannot1</h1>";
							header('location:../chat.php');
						}
		        }

		        elseif ($run2==TRUE) {

		        	
						$query4="INSERT INTO `".$chatroom1."`(`time`, `from`, `to`,`type`, `filename`, `filelocation`) VALUES ('$time','$from','$to','image','$filename','$location')";

						$run=mysqli_query($con,$query4);


						if ($run==TRUE) {
								
							echo "<h1>done</h1>";
							header('location:../chat.php');
						}

						else{
							echo "<h1>cannot2</h1>";
							header('location:../chat.php');
						}

		                 
		        }
		        else{

		        	echo "<h1>cannot3</h1>";
		        }
		
	}
	else{
		mkdir("../documents/pdf/".$chatroom."");

		$location="documents/pdf/".$chatroom."/".$filename."";
		$location1="../documents/pdf/".$chatroom."/".$filename."";
		move_uploaded_file($tmp,$location1);

				$query1="SELECT * FROM `".$chatroom."` WHERE 1";
		        $run1=mysqli_query($con,$query1);



		         $query2="SELECT * FROM `".$chatroom1."` WHERE 1";
		         $run2=mysqli_query($con,$query2);


		        if ($run1==TRUE) {
		             


						$query3="INSERT INTO `".$chatroom."`(`time`, `from`, `to`,`type`, `filename`, `filelocation`) VALUES ('$time','$from','$to','image','$filename','$location')";

						$run=mysqli_query($con,$query3);


						if ($run==TRUE) {
								
							echo "<h1>done</h1>";
							header('location:../chat.php');
						}

						else{
							echo "<h1>cannot1</h1>";
							header('location:../chat.php');
						}
		        }

		        elseif ($run2==TRUE) {

		        	
						$query4="INSERT INTO `".$chatroom1."`(`time`, `from`, `to`,`type`, `filename`, `filelocation`) VALUES ('$time','$from','$to','image','$filename','$location')";

						$run=mysqli_query($con,$query4);


						if ($run==TRUE) {
								
							echo "<h1>done</h1>";
							header('location:../chat.php');
						}

						else{
							echo "<h1>cannot2</h1>";
							header('location:../chat.php');
						}

		                 
		        }
		        else{

		        	echo "<h1>cannot3</h1>";
		        	header('location:../chat.php');
		        }


	}



}

else{

echo "cannot upload";
header('location:../chat.php');


}


















?>
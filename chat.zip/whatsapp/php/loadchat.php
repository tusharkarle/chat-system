<?php



include 'connection.php';
$_SESSION['chatfrom']=$_POST['chat-from'];
$_SESSION['chatto']=$_POST['chat-to'];

header('location:../chat.php');
echo $_SESSION['chatfrom'];
echo $_SESSION['chatto'];









?>
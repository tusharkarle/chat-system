<?php

$user=$_POST['username'];
$fullname=$_POST['fullname'];

$mail=$_POST['mail'];
$password=$_POST['pswd'];

$file=$_FILES['photo'];
$photoname=$file['name'];


$tmp=$file['tmp_name'];
$extension = pathinfo($photoname, PATHINFO_EXTENSION);

$loc='../images/'.$file['name'];


if($extension=='jpg' || $extension=='jpeg' || $extension=='png' || $extension=='gif'){

		move_uploaded_file($tmp,$loc);



		include 'connection.php';



		$query="UPDATE `user-data` SET `fullname`='$fullname',`mail`='$mail',`password`='$password',`photoname`='$photoname' WHERE uname='$user'";

		$run=mysqli_query($con,$query);

		if ($run==TRUE) {
			header('location:../search-friends.php');
			echo("SUCCESS");

		}
		else{

			echo "UNSUCCESSFULL";
		}
}
else{
	echo "<h4>please upload iamge only</h4>";
}









?>
<?php
$user=$_POST['username'];

$friend=$_POST['fname'];

include 'connection.php';

$query="SELECT * FROM `user-data` WHERE uname='$friend'";

$result=mysqli_query($con,$query);

$num=mysqli_num_rows($result);


if ($friend==$user) {
	echo "<h2>Not found search again";

}
elseif($num==1){
	echo ("<h1 id=".$friend.">$friend</h1>");
	echo "<script type='text/javascript'>";
	echo "$('#".$friend."').click(function(){

								var person='".$friend."';
								var we='".$_SESSION['username']."';
								console.log(person);
								console.log(we);

								$('#chat-to').val(person);
								$('#chat-from').val(we);

								$('#click').click();";
	echo "});";

	echo "</script>";
}

else{

	echo "<h2>Not found search again";
}
?>
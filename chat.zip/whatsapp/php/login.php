<?php 

$uname=$_POST['uname'];

$password=$_POST['pswd'];
//$photo=$_POST['photo'];

session_start();


$con=mysqli_connect('localhost','root','','whatsapp');


$query="SELECT * FROM `user-data` WHERE uname='$uname' && password='$password'";

$result=mysqli_query($con,$query);
$num=mysqli_num_rows($result);

if ($num==1) {

	echo "success";
	$_SESSION['username']=$uname;
	header('location:../search-friends.php');

}
else {
	
	echo "unsuccess";

}























?>
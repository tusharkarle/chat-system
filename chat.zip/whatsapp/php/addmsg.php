<?php


$msg=$_POST['msg'];
$time=$_POST['time'];
$from=$_POST['from'];
$to=$_POST['to'];
$message="message";


include 'connection.php';






		$chatroom=$from."-".$to;

      	$chatroom1=$to."-".$from;

          $query1="SELECT * FROM `".$chatroom."` WHERE 1";
        $run1=mysqli_query($con,$query1);



         $query2="SELECT * FROM `".$chatroom1."` WHERE 1";
         $run2=mysqli_query($con,$query2);


        if ($run1==TRUE) {
             


				$query3="INSERT INTO `".$chatroom."`(`msg`, `time`, `from`, `to`,`type`) VALUES ('$msg','$time','$from','$to','$message')";

				$run=mysqli_query($con,$query3);


				if ($run==TRUE) {
						
					echo "<h1>done</h1>";
				}

				else{
					echo "<h1>cannot1</h1>";
				}
        }

        elseif ($run2==TRUE) {

        		$query4="INSERT INTO `".$chatroom1."`(`msg`, `time`, `from`, `to`,`type`) VALUES ('$msg','$time','$from','$to','$message')";

				$run=mysqli_query($con,$query4);


				if ($run==TRUE) {
						
					echo "<h1>done</h1>";
				}

				else{
					echo "<h1>cannot2</h1>";
				}

                 
        }
        else{

        	echo "<h1>cannot3</h1>";
        }


        

        

























?>
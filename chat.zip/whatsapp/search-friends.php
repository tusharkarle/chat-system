<!DOCTYPE html>
<html>
<head>
	<title>whatsapp</title>
	    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="css/list.css">
</head>
<body>
<div id="loading" class="container-fluid text-center ">


	</script>
	

</div>


<div id="total">

	<!--navbar-->
	<nav class="navbar navbar-expand-lg  text-weight-bold sticky-top bg-dark text-white " style="background-color: #00cc00;">
	  <a class="navbar-brand text-white " href="#"><h3>Whatsapp</h3></a>
	  <div class="name ml-auto text-center " style="display: flex;">
	  	<div class="text-center align-items-center " id="profile" style="display: flex;padding-right:2vh;">
	  	<?php 
	  		include 'connection.php';



        $query5="SELECT * FROM `user-data` WHERE uname='".$_SESSION['username']."'";
        $run5=mysqli_query($con,$query5);

        if ($data=mysqli_fetch_array($run5)) {

            $image="images/".$data['photoname'];

      ?>
            
        <img src="<?php echo $image; ?>" alt="icon" style="width:5vh;border-radius: 20vh;">

    <?php
}

	  	echo "<h6 class='text-center'>Hello ".$_SESSION['username']."</h6>";


	  	?>
	  </div>


	  <script type="text/javascript">
	  	
	  	$("#profile").click(function(){

	  		window.location.href='profile.php';

	  	})
	  </script>

	  	 <form id="logout" action="php/logout.php" class="align-items-center text-center" style="align-content: center;padding-top: 2vh;">
                
            
            <button class="btn btn-danger text-center">LOG-OUT</button>

        </form>


	  </div>



	</nav>
	

<!--main-->
<div class=" container-fluid  text-center " id="" style="min-height: 80vh;background-color:#ccffb3;" >
	<div class="row" >

			<div class="col-xl-6 " style="background-color:#ccffb3; max-height: 80vh;">
		
		<div class="header border-bottom">
			<h2>Search Friends</h2>
			
		</div>


		<div>
			

			<!-- Search form -->
		<div class="md-form mt-0">
		  <input class="form-control" id="friend-name" type="text" placeholder="Search" aria-label="Search">
		  <input type="hidden" id="username1" name="username1" value="<?php echo $_SESSION['username']; ?>">
		  
		  <button class="btn-success btn-lg"  id="Search1">Search</button> 
		</div>

		<div class="" id="result">
			
			
			

		</div>

		<script>


		$("#Search1").click(function(){

			var fri=$("#friend-name").val();
			var user=$("#username1").val();

			$("#result").empty();

			$.ajax({

				url:'php/friend-search.php',
				type:'POST',
				data:{
						fname:fri,
						username:user
				},
				success:function(result){
					$("#result").append(result);
				}


			});


	});
		</script>
		

		

		</div>








	</div>
	<br>








	<div class="col-xl-6 " style="background-color: #00CCFF;min-height: 83vh;">
		
		<div class=" container-fluid  border-bottom" style="" >
			<h2>Friends</h2>
			<br>

			
		</div>

		<div class="" style="overflow-y: scroll;min-height: 70vh;background-color: #00CCFF;">


			<?php
			


				$query="SELECT * FROM `user-data`";

				$data=mysqli_query($con,$query);
				
				while($row=mysqli_fetch_array($data))
				{
				
					if ($row['uname']==$_SESSION['username']) {
						
					}
					else{
						echo "<button id='".$row['uname']."' class='".$row['uname']." btn btn-info btn-block'><h4>".$row['uname']."<h4></button>";
						echo "<br>";
					}
				 


				}
			

			?>












		</div>


		<div class="hidden bg-dark" id="setdata" >

			<form action="php/loadchat.php" method="post">
				<input type="text" name="chat-to" value="asach" id="chat-to">
				<input type="text" name="chat-from" value="asach1" id="chat-from">

				<input type="submit" name="Submit" id="click">
				
			</form>

			


		</div>

			<script type="text/javascript">


				$("#setdata").hide();
				
				<?php


					$query="SELECT * FROM `user-data`";

						$data=mysqli_query($con,$query);
						
						while($row=mysqli_fetch_array($data)){
						
						

							echo "$('#".$row['uname']."').click(function(){

								var person='".$row['uname']."';
								var we='".$_SESSION['username']."';
								console.log(person);
								console.log(we);

								$('#chat-to').val(person);
								$('#chat-from').val(we);


								$('#click').click();







								
								

								
								

								});
								";

						


						}
					


				?>




			</script>









	</div>





</div>

</div>
</div>



<!--bottom-->

	<nav class="navbar navbar-expand-lg navbar-dark bg-dark text-weight-bold \s d-flex justify-content-center">

	  <a class="navbar-brand display-5 text-center" href="#" ><h7>This website is designed by TUSHAR KARLE.</h7></a>
	  
	</nav>

	

















</body>
</html>
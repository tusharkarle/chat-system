<?php





$_SESSION['chat-person']=$_POST['person'];




echo $_SESSION['chat-person'];

header('location:chat.php');











?>
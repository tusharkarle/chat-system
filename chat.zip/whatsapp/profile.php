<!DOCTYPE html>
<html>
<head>
	<title>whatsapp</title>
	    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="css/index.css">
</head>
<body>



<div id="total">

	<!--navbar-->
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark text-weight-bold sticky-top">
	  <a class="navbar-brand " href="index.php"><h3>Whatsapp</h3></a>
	 
	  </button>

	</nav>

<!--main-->
<div class="container text-center" width="100%"  style="background-color:#82c5ff;min-height: 90vh;">



	<div class="header bg-info text-center rounded">
		<h1>Edit Profile</h1>
	</div>
	<br>
	<?php

	
	include 'connection.php';
	$user=$_SESSION['username'];


	$query="SELECT * FROM `user-data` WHERE uname='$user'";


	$result=mysqli_query($con,$query);

	$run=mysqli_fetch_assoc($result);

	$image="images/".$run['photoname'];

	

	?>

	<div>
		 <form action="php/updateprofile.php" method="post" enctype="multipart/form-data" class="needs-validation" novalidate>
				    <div class="form-group">
				      <label for="uname">Enter Full name:</label>
				      <input type="text" class="form-control rounded" id="fname" placeholder="<?php echo($run['fullname']);?>" name="fullname" required>
				      <div class="valid-feedback">Valid.</div>
				      <div class="invalid-feedback">Please fill out this field.</div>
				    </div>

				    <input type="hidden" value="<?php echo($user);?>" name="username">
				    <div class="form-group">
				      <label for="mail">Enter mail:</label>
				      <input type="text" class="form-control" id="mail" placeholder="<?php echo($run['mail']);?>" name="mail" required>
				      <div class="valid-feedback">Valid.</div>
				      <div class="invalid-feedback">Please fill out this field.</div>
				    </div>
				    
				    <div class="form-group">
				      <label for="pwd">Password:</label>
				      <input type="text" class="form-control" id="pssd" placeholder="New password" name="pswd" required>
				      <div class="valid-feedback">Valid.</div>
				      <div class="invalid-feedback">Please fill out this field.</div>
				    </div>
				    <div class="form-group form-check">
				      <label class="form-check-label">
				      	<label for="file">Profile Picture:</label>
				      	 <img src="<?php echo $image; ?>" alt="icon" style="width:7vh;border-radius: 20vh;">
				        <input type="file" class="form-control-file border" name="photo">
				        <div class="valid-feedback">Valid.</div>
				        <div class="invalid-feedback">Check this checkbox to continue.</div>
				      </label>
				    </div>
				    <button type="submit" class="btn btn-warning">Update</button>
				  	<br>
			</form>
	</div>


</div>
<!--bottom-->

	<nav class="navbar navbar-expand-lg navbar-dark bg-dark text-weight-bold \s d-flex justify-content-center fixed-bottom">
	  <a class="navbar-brand display-5 text-center" href="#" ><h7>This website is designed by TUSHAR KARLE.</h7></a>
	  
	</nav>

</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<title>whatsapp</title>
	    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<link rel="stylesheet" type="text/css" href="css/index.css">
</head>
<body>
<div id="loading" class="container-fluid text-center ">

	<script type="text/javascript">
		setTimeout(function(){
			console.log("hell0");
		},1000);

	</script>
	

</div>


<div id="total">

	<!--navbar-->
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark text-weight-bold sticky-top">
	  <a class="navbar-brand " href="#"><h3>Whatsapp</h3></a>
	 
	</nav>

<!--main-->
<div class="container-fluid d-flex justify-content-center "  id="mid" style="background-color:#82c5ff;">
	<div class="" id="login-sign"> 
		<div class="span" id="top" style="display: flex;">
			<button  class="btn btn-primary" id="log">Login</button>

			<button  class="btn btn-warning" id="cana">Create a new account</button>
			<br>
		</div>

		<div id="login">

			
				<form action="php/login.php" method="post" class="needs-validation" novalidate>
				    <div class="form-group">
				      <label for="uname">Username:</label>
				      <input type="text" class="form-control" id="uname" placeholder="Enter username" name="uname" required>
				      <div class="valid-feedback">Valid.</div>
				      <div class="invalid-feedback">Please fill out this field.</div>
				    </div>
				    <div class="form-group">
				      <label for="pwd">Password:</label>
				      <input type="text" class="form-control" id="pwd" placeholder="Enter password" name="pswd" required>
				      <div class="valid-feedback">Valid.</div>
				      <div class="invalid-feedback">Please fill out this field.</div>
				    </div>
				    <div class="form-group form-check">
				      <label class="form-check-label">
				        <input class="form-check-input" type="checkbox" name="remember">Remember me.
				      </label>
				    </div>
				    <button type="submit" class="btn btn-primary">Submit</button>
				  </form>
				
		</div>

		<div id="signup">
			
				<form action="php/signup.php" method="post" enctype="multipart/form-data" class="needs-validation" novalidate>
				    <div class="form-group">
				      <label for="uname">Enter Full name:</label>
				      <input type="text" class="form-control" id="fname" placeholder="Enter username" name="fullname" required>
				      <div class="valid-feedback">Valid.</div>
				      <div class="invalid-feedback">Please fill out this field.</div>
				    </div>
				    <div class="form-group">
				      <label for="mail">Enter mail:</label>
				      <input type="text" class="form-control" id="mail" placeholder="Enter username" name="mail" required>
				      <div class="valid-feedback">Valid.</div>
				      <div class="invalid-feedback">Please fill out this field.</div>
				    </div>
				    <div class="form-group">
				      <label for="uname">Select Username:</label>
				      <input type="text" class="form-control" id="username" placeholder="Enter username" name="uname" required>
				      <div class="valid-feedback">Available.</div>
				      <div class="invalid-feedback">Please select another username</div>
				    </div>
				    <div class="form-group">
				      <label for="pwd">Password:</label>
				      <input type="text" class="form-control" id="pssd" placeholder="Enter password" name="pswd" required>
				      <div class="valid-feedback">Valid.</div>
				      <div class="invalid-feedback">Please fill out this field.</div>
				    </div>
				    <div class="form-group form-check">
				      <label class="form-check-label">
				      	<label for="file">Profile Picture:</label>
				        <input type="file" class="form-control-file border" name="photo">
				        <div class="valid-feedback">Valid.</div>
				        <div class="invalid-feedback">Check this checkbox to continue.</div>
				      </label>
				    </div>
				    <button type="submit" class="btn btn-primary">Submit</button>
				  	<br>
				  </form>


				  <?php

















				  ?>
				
		</div>
		
	</div>
</div>

</div>
<!--bottom-->

	<nav class="navbar navbar-expand-lg navbar-dark bg-dark text-weight-bold \s d-flex justify-content-center fixed-bottom">
	  <a class="navbar-brand display-5 text-center" href="#" ><h7>This website is designed by TUSHAR KARLE.</h7></a>
	  
	</nav>

	<script>
		// Disable form submissions if there are invalid fields
		(function() {
		  'use strict';
		  window.addEventListener('load', function() {
		    // Get the forms we want to add validation styles to
		    var forms = document.getElementsByClassName('needs-validation');
		    // Loop over them and prevent submission
		    var validation = Array.prototype.filter.call(forms, function(form) {
		      form.addEventListener('submit', function(event) {
		        if (form.checkValidity() === false) {
		          event.preventDefault();
		          event.stopPropagation();
		        }
		        form.classList.add('was-validated');
		      }, false);
		    });
		  }, false);
		})();




		$("#log").click(function(){
			$("#signup").hide();
			$("#login").show();

		});

		$("#cana").click(function(){
			$("#signup").show();
			$("#login").hide();

		});

	




</script>
</body>
</html>